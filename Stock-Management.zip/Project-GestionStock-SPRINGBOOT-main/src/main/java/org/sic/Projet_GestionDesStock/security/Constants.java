package org.sic.Projet_GestionDesStock.security;

public class Constants {
    public static final String SECRET = "ugvhgvjkh86a6rsj";
    public static final long EXPIRATION_TIME = 864_000_000;
    public static final String TOKEN_PREFEX = "Bearer ";
    public static final String HEADE_STRING = "Authorization";
}
