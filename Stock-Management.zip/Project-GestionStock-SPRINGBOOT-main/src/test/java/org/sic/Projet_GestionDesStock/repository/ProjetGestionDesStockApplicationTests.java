package org.sic.Projet_GestionDesStock.repository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.sic.Projet_GestionDesStock.entity.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetGestionDesStockApplicationTests {




	@Test
	void contextLoads() {

	}




}
